create function handle_new_user() returns trigger
    security definer
    language plpgsql
as
$$begin
  insert into public.profiles (id, email, full_name, phone_number, avatar_url)
  values (new.id, new.
  raw_user_meta_data->>'email', new.raw_user_meta_data->>'full_name', new.raw_user_meta_data->>'phone_number', new.raw_user_meta_data->>'avatar_url');
  return new;
end;
$$;

alter function handle_new_user() owner to postgres;

grant execute on function handle_new_user() to anon;

grant execute on function handle_new_user() to authenticated;

grant execute on function handle_new_user() to service_role;

